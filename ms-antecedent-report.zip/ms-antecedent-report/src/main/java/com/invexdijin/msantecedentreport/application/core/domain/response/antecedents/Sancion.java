package com.invexdijin.msantecedentreport.application.core.domain.response.antecedents;

import lombok.Data;

@Data
public class Sancion {
    public String sancion;
    public String termino;
    public String clase;
    public String suspendida;
}
