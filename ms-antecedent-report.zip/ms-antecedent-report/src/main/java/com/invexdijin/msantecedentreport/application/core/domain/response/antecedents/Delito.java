package com.invexdijin.msantecedentreport.application.core.domain.response.antecedents;

import lombok.Data;

@Data
public class Delito {
    private String descripcionDelDelito;
}
