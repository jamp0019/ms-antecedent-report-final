package com.invexdijin.msantecedentreport.application.core.domain.response.searchperson;

import lombok.Data;

@Data
public class Location {

    private float lng;
    private float lat;

}
