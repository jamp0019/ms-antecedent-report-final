package com.invexdijin.msantecedentreport.application.core.domain.response.antecedents;

import lombok.Data;

@Data
public class TokenRenew {
    private String accessToken;
    private String tokenType;
}
