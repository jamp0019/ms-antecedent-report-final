package com.invexdijin.msantecedentreport.application.core.exception;

public class InternalServerError extends RuntimeException {
    public InternalServerError(String message) {
        super(message);
    }
}
