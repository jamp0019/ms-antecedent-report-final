package com.invexdijin.msantecedentreport.application.core.domain.response.antecedents;

import lombok.Data;

@Data
public class Instancia {

    private String nombre;
    private String autoridad;
    private String fechaProvidencia;
    private String fechaEfectoJuridicos;
}
