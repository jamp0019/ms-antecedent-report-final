package com.invexdijin.msantecedentreport.application.core.domain.response.searchperson;

import lombok.Data;

@Data
public class Northeast {

    private Object lng;
    private Object lat;

}
