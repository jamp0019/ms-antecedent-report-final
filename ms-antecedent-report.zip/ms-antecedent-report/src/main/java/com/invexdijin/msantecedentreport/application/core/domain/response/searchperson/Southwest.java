package com.invexdijin.msantecedentreport.application.core.domain.response.searchperson;

import lombok.Data;

@Data
public class Southwest {

    private Object lng;
    private Object lat;

}
