package com.invexdijin.msantecedentreport.application.core.domain.response.antecedents;

import lombok.Data;

@Data
public class Signature {

    public String dateTime;
    public String message;

}
