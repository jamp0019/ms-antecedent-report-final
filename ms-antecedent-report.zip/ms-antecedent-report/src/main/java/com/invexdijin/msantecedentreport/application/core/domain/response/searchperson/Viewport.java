package com.invexdijin.msantecedentreport.application.core.domain.response.searchperson;

import lombok.Data;

@Data
public class Viewport {

    private Southwest southwest;
    private Northeast northeast;

}
