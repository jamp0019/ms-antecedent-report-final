package com.invexdijin.msantecedentreport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsAntecedentReportApplicationTests {

	@Test
	void contextLoads() {
	}

}
